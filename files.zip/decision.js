const crypto = require('crypto');
const { REQUEST_ID, COLS, sb, getRequest } = require('./_supabase');

const safeEqual = (a, b) => {
  const x = crypto.createHash('sha256').update(String(a)).digest();
  const y = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(x, y);
};

module.exports = async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const body = typeof req.body === 'string' ? JSON.parse(req.body || '{}') : (req.body || {});
    const { decision, pin } = body;

    if (!['approved', 'rejected'].includes(decision))
      return res.status(400).json({ error: 'Invalid decision.' });
    if (!process.env.APPROVER_PIN)
      return res.status(500).json({ error: 'Server is not configured.' });
    if (!pin || !safeEqual(pin, process.env.APPROVER_PIN))
      return res.status(401).json({ error: 'Incorrect approver PIN.' });

    // Atomic: only updates if no decision exists yet, so duplicates are impossible.
    const upd = await sb(`permission_requests?id=eq.${REQUEST_ID}&decision=is.null&select=${COLS}`, {
      method: 'PATCH',
      headers: { Prefer: 'return=representation' },
      body: JSON.stringify({ decision, decided_at: new Date().toISOString() }),
    });
    if (!upd.ok) { console.error(upd.data); return res.status(500).json({ error: 'Database error. Decision not saved.' }); }

    if (Array.isArray(upd.data) && upd.data.length === 1)
      return res.status(200).json({ saved: true, request: upd.data[0] });

    const current = await getRequest();
    if (current && current.decision)
      return res.status(409).json({ error: 'A decision was already recorded.', request: current });
    return res.status(404).json({ error: 'Request not found.' });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'Something went wrong. Decision not saved.' });
  }
};
