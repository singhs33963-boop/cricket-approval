# Cricket Permission Request – Deployment (100% free)

Stack: static page + Vercel serverless functions (/api) + Supabase Postgres.
The Supabase secret key lives ONLY in Vercel environment variables.

## 1. Supabase (database)
1. https://supabase.com → sign up → New project (free plan). Save the DB password.
2. Left menu → SQL Editor → New query → paste `supabase/schema.sql` → Run.
3. Table Editor → `permission_requests` should show 1 row with an empty `decision`.
4. Project Settings → API Keys / Data API:
   - copy the **Project URL** → SUPABASE_URL
   - copy the **secret** key (or legacy `service_role`) → SUPABASE_SERVICE_ROLE_KEY
   Never paste this key in index.html or commit it to GitHub.

## 2. GitHub
Create a new repo, upload this folder's contents (.env is git-ignored), commit.

## 3. Vercel (hosting)
1. https://vercel.com → sign up with GitHub (Hobby plan is free).
2. Add New → Project → import the repo. Framework Preset: **Other**. Leave build settings empty.
3. Environment Variables (add before deploying):
   - SUPABASE_URL
   - SUPABASE_SERVICE_ROLE_KEY
   - APPROVER_PIN  (any private PIN; give it only to USM)
4. Deploy. Your public URL: `https://<project>.vercel.app`

## 4. Share & test
- Send the URL to USM plus the PIN (separately).
- Click APPROVE/REJECT → check Supabase Table Editor: `decision` and `decided_at` are filled.
- Reload or retry: the page shows the locked decision; a second write is rejected (HTTP 409).
- To reset while testing, run in SQL Editor:
  `update permission_requests set decision=null, decided_at=null where id='cricket-2026-10-17-shubham';`

Note: free Supabase projects pause after ~1 week of inactivity; click "Restore" in the dashboard if that happens.
