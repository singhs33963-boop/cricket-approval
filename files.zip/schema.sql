create table if not exists public.permission_requests (
  id           text primary key,
  title        text not null,
  requested_by text not null,
  request_date date not null,
  purpose      text not null,
  approver     text not null,
  decision     text check (decision in ('approved','rejected')),
  decided_at   timestamptz,
  created_at   timestamptz not null default now(),
  -- a decision and its timestamp must exist together
  constraint decision_has_time check ((decision is null) = (decided_at is null))
);

-- Lock the table: no public access. Only the server (secret key) can read/write.
alter table public.permission_requests enable row level security;

insert into public.permission_requests (id, title, requested_by, request_date, purpose, approver)
values ('cricket-2026-10-17-shubham','Cricket Permission Request','Shubham','2026-10-17','Cricket match','USM')
on conflict (id) do nothing;
