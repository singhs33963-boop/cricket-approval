const REQUEST_ID = 'cricket-2026-10-17-shubham';

async function sb(path, options = {}) {
  const url = process.env.SUPABASE_URL, key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) throw new Error('Server is not configured');
  const headers = { apikey: key, 'Content-Type': 'application/json', ...(options.headers || {}) };
  if (!key.startsWith('sb_')) headers.Authorization = `Bearer ${key}`; // legacy JWT keys
  const res = await fetch(`${url.replace(/\/$/, '')}/rest/v1/${path}`, { ...options, headers });
  const text = await res.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  return { ok: res.ok, status: res.status, data };
}

const COLS = 'id,title,requested_by,request_date,purpose,approver,decision,decided_at';
async function getRequest() {
  const r = await sb(`permission_requests?id=eq.${REQUEST_ID}&select=${COLS}`);
  if (!r.ok) throw new Error('Database read failed');
  return r.data && r.data[0] ? r.data[0] : null;
}

module.exports = { REQUEST_ID, COLS, sb, getRequest };
