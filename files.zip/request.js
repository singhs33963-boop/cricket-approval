const { getRequest } = require('./_supabase');

module.exports = async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const row = await getRequest();
    if (!row) return res.status(404).json({ error: 'Request not found. Did you run schema.sql?' });
    return res.status(200).json(row);
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'Could not load the request.' });
  }
};
